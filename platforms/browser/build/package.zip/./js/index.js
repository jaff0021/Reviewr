let imageFile;

function onDeviceReady(){
    console.log("Ready");
    let saveButton = document.getElementById("saveBtn");
    saveButton.addEventListener("click", saveReview);
    let cancelButton = document.getElementById("cancelBtn");
    cancelButton.addEventListener("click", cancelModal);
    
    let pictureButton = document.getElementById("pictureBtn");
    cancelButton.addEventListener("click", takePicture);
}

function cancelModal(){
    
}

function saveReview(){
    let itemNameToBeSaved = document.getElementById("itemName").value;
    let ratingToBeSaved;
    
    let timeStamp = new Date().getTime() / 1000;
    
    let person = {id: timeStamp,
                  itemName:itemNameToBeSaved,
                  rating:dateToBeSaved,
                  img:imageFile,
                 };
    
}

function takePicture(){
    
}

function deleteReview(){
    
}

function saveToLocalStorage(){
    
}

function retrieveFromLocalStorage(){
    
}

function displayReviews(){
    
}

function openReview(){
    
}


////global declarations
//var rating = 3;
//var stars = null;
//
////initial setup
//document.addEventListener('DOMContentLoaded', function(){
//  stars = document.querySelectorAll('.star');
//  addListeners();
//  setRating(); //based on global rating variable value
//});
//
//function addListeners(){
//  [].forEach.call(stars, function(star, index){
//    star.addEventListener('click', (function(idx){
//      console.log('adding listener', index);
//      return function(){
//        rating = idx + 1;  
//        console.log('Rating is now', rating)
//        setRating();
//      }
//    })(index));
//  });
//  
//}
//
//function setRating(){
//  [].forEach.call(stars, function(star, index){
//    if(rating > index){
//      star.classList.add('rated');
//      console.log('added rated on', index );
//    }else{
//      star.classList.remove('rated');
//      console.log('removed rated on', index );
//    }
//  });
//}




//navigator.camera.getPicture( successCallback, errorCallback, options ); 


//navigator.camera.getPicture(onSuccess, onFail, { quality: 50,
//    destinationType: Camera.DestinationType.FILE_URI });
//
//function onSuccess(imageURI) {
//    var image = document.getElementById('myImage');
//    image.src = imageURI;
//}
//
//function onFail(message) {
//    alert('Failed because: ' + message);
//}



//var options = {
//  quality: 80,
//  destinationType: Camera.DestinationType.FILE_URI,
//  encodingType: Camera.EncodingType.PNG,
//  mediaType: Camera.MediaType.PICTURE,
//  pictureSourceType: Camera.PictureSourceType.CAMERA,
//  allowEdit: true,
//  targetWidth: 300,
//  targetHeight: 300
//}

//
//navigator.camera.cleanup( successCallback, errorCallback );